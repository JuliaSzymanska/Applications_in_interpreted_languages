/*jshint esversion: 6 */
exports.home = (req, res) => {
    res.json({
        "status": "working "
    });
};